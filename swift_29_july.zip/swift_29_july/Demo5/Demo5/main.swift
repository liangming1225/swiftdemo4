//
//  main.swift
//  Demo5
//
//  Created by Mojave on 2019/7/29.
//  Copyright © 2019 Mojave. All rights reserved.
//

import Foundation

print("Hello, World!")

