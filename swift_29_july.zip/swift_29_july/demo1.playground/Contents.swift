import UIKit

var str = "Hello, playground"
var str2 = "HiHi"

print(str)
print(str2)

