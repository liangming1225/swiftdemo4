import UIKit

var x1 = true
let x2 = 5
var x3:Float = 3.14

print("the test is finished? \(x1)")
print("I have \(x2) apples")
print("pi is \(x3) in this program")

print("x2*x3=\(Float(x2)*x3)")

