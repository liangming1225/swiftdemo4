import UIKit

print("hello chtti201")
var greeting:String = "Hello"
greeting += " world"
print(greeting)
greeting += " world"
print(greeting)
greeting.append(Character("!"))
print(greeting)

var a:Int=1; var b=2; var c=3
var d=a+b+c
print(d)
