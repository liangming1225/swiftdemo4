import UIKit

var products = ["iphoneXR", "iphoneXS", "iphoneXS-Max"]

var bestSelling = products[1]
print(bestSelling)
//var anotherChoice = products[-1]
//print(anotherChoice)
var renew = products[2]
print(renew)
products[2]="iPad"
print(products[2])
print(products)
//products[3] = "apple Watch"
let emptyArray = [String]()
print(emptyArray)
	
