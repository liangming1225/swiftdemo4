import UIKit

var var1="hihi, I am variable1"
let var2 = "hihi, i am an immutable variable2"
print(var1)
print(var2)
var1 = "changed"
print(var1)
//var2 = "changed"
var var3:String
var3 = "var3 is lazy"
var3 = "var3 is a bit lazy"
print(var3)
let var4:String
var4 = "var4 is laszy, too"
//var4 = "var4 is too lazy"
print(var4)
var var5:String?
print(var5)
var5 = "got some value"
print(var5)
