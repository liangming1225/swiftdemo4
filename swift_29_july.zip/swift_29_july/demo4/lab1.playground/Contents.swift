import UIKit

var str = "Hello, playground"
var str2 = "HiHi2"
var str3 = "Welcome3"
print(str2)
