import UIKit
var name:String? = "chtti/chtti201"
let defaultUser = "scott/tiger"
let printMessage = "Hi, \(name ?? defaultUser), welcome to use the system"
