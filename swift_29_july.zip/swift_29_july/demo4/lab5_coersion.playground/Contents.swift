import UIKit

var radius=3
var pi=3.14
var area = Double(radius*radius)*pi
print(area)

