import UIKit
class PolyShape {
    var colorId:Int = 0
    var shapes:Int
//    init(colorId:Int, shapes:Int) {
//        self.colorId = colorId
//        self.shapes = shapes
//    }
    init(shapes:Int) {
        self.shapes = shapes
    }
    func simpleDescription()->String {
        return "color id = \(colorId), shape count = \(shapes)"
    }
    
}
//let p1 = PolyShape(colorId: 5, shapes: 7)
let p1 = PolyShape(shapes: 7)
print(p1.simpleDescription())
