import UIKit

var str = "Hello, playground"

let weights = [1.3, 3.9, 8.6, 4.7, 100.0, 2.0, 9.0]
var total = 0.0
for weight in weights {
    total += weight
}
print("total=\(total)")
