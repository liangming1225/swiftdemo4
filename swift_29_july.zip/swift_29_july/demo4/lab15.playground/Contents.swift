import UIKit

func sayHello(name:String, day:String, time:Int)->String {
    var result = ""
    for _ in 0...time-1 {
        result += "Hi, \(name), it's \(day)"
    }
    return result
}

sayHello(name: "Mark", day: "Labor's day", time: 3)
var str = "Hello, playground"

func getSpec()->(Double, Int, Bool) {
    return (10.0, 	3, false)
}

getSpec()
