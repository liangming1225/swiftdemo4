import UIKit

var v1 = 1_000_000
var v2 = 100_0000
print(v1==v2)
let v3 = 500
print(v3)
let v4:Float = 3.14
print(v4)
print(type(of: v1))
print(type(of: v2))
print(type(of: v3))
print(type(of: v4))
