import UIKit

//let product = "Apple"
//let product = "Pineapple"
let product = "Android"

switch product {
case "Apple":
    let _ = "Good product"
case let x where x.hasSuffix("pple"):
    let message = "any product"
default:
    let message = "any else"
}

let score = true
switch score {
case true:
    let message = "pass"
case false:
    let message = "fail"
}
