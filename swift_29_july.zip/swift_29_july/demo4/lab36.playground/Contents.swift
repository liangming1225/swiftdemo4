import UIKit
struct FixLength {
    var initValue:Int
    let length:Int
}

var firstPosition = FixLength(initValue: 3, length: 3)
firstPosition.initValue = 8
print("start \(firstPosition.initValue), length in \(firstPosition.length)")
let rangeOfFive = FixLength(initValue: 2, length:  5)
//rangeOfFive.initValue = 3
//rangeOfFive.length = 7
