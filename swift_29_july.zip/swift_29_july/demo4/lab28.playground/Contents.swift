import UIKit

enum Status {
    case SUCCESS
    case FAIL
    case RETRY
    case ABORT
}
enum Status2 {
    case SUCCESS, FAIL, RETRY, ABORT
}

var connectStatus = Status.ABORT
connectStatus = .FAIL
connectStatus = .RETRY
switch(connectStatus) {
case .ABORT:
    print("connect abort")
case .FAIL:
    print("connect fail")
case .SUCCESS:	
    print("connect success")
case .RETRY:
    print("retrying...")
}
var str = "Hello, playground"
